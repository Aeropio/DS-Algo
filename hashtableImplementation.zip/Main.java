class Main {
  public static void main(String[] args) {
    //System.out.println("Hello world!");
    HashtableLinked hashtable = new HashtableLinked(3);
    hashtable.insert(1);
    hashtable.insert(2);
    hashtable.insert(10);

    hashtable.print();

  }
}

class Node
 {
    int data;
    Node next;
    public Node(int data)
    {
        this.data = data;
        next = null;
    }
    public void setNext(Node node){
      this.next = node;
    }
    public Node getNext(){
      return this.next;
    }
 
 }
 class HashtableLinked
 {
    private Node[] arrayLinked;
   // private Node head;
    private int size;
    private int tablesize;
 
    public HashtableLinked(int ts)
    {
        arrayLinked = new Node[ts];
        size = 0;
       // head = null;
        tablesize = ts;
    }
 
    public void insert(int data)
    {
        size++;
        int pos = (size%tablesize);
        Node newNode = new Node(data);
         
        if(arrayLinked[pos]==null)
        {
            arrayLinked[pos] = newNode;
        }
        else
        {
            Node curr = arrayLinked[pos];
            while(curr.getNext()!=null)
            {
                curr=curr.getNext();
            }
            curr.setNext(newNode);
        }
    }
 
    public void print()
    {
        for(int i=0;i<arrayLinked.length;i++)
        {
            Node start = arrayLinked[i];
            while(start!=null)
            {
                System.out.println(start.data);
                start = start.next;
            }
        }
    }
 
 
}
 
